package PROGRAMAS_EM_JAVA.Projeto_Analise_Algortimos.utils;

public enum Cenario {
    ORDENADO,
    INVERSO,
    ALEATORIO,
    QUASE_ORDENADO
}
